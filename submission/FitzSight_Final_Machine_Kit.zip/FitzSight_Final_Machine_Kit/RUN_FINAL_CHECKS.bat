@echo off
python scripts\final_machine_check.py --output final_machine_report.json
pause
