#!/usr/bin/env sh
set -eu
python scripts/final_machine_check.py --output final_machine_report.json
