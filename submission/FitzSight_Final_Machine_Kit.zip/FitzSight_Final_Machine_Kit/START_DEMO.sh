#!/usr/bin/env sh
set -eu
python scripts/start_demo.py
